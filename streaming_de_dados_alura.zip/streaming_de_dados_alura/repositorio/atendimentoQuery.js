const query = require('../infra/database/queries');

class Atendimento {
    adiciona(atendimento) {
        const sql = 'INSERT INTO atendimentos(cliente, pet, servico, status, observacoes, data, dataCriacao) VALUES (?, ?, ?, ?, ?, ?, ?)'

        return query(sql, [atendimento.cliente, atendimento.pet, atendimento.servico, atendimento.status, atendimento.observacoes, atendimento.data, atendimento.dataCriacao])
    }

    lista() {
        const sql = 'SELECT * FROM atendimentos'

        return query(sql);
    }
}

module.exports = new Atendimento()