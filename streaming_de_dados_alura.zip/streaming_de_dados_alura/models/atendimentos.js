const { default: axios } = require('axios');
const moment = require('moment');
const connection = require('../infra/database/connection');
const repositorio = require('../repositorio/atendimentoQuery')

class Atendimento {
    constructor() {
        this.validarData = function({data, dataCriacao}){
            moment(data).isSameOrAfter(dataCriacao)
        };

        this.valida = function(parametros) {
            this.validacoes.filter(campo => {
                const { nome } = campo;
                const parametro = parametros[nome];

                return !campo.valido(parametro)
            })
        }

        this.validarCliente = function(tamanho){
            tamanho >= 5
        };

        this.validacoes = [

            
            {
                nome: 'data',
                valida: this.validarData,
                mensagem: 'Data deve ser maior ou igual a data atual.'
            },
            {
                nome: 'cliente',
                valido: this.validarCliente,
                mensagem: 'Cliente deve ter pelo menos cinco caracteres.'
            }
        ]
    }

    adiciona(atendimento) {
        // Formatação de datas.
        const dataCriacao = moment().format('YYYY-MM-DD HH:MM:SS');
        const data = moment(atendimento.data, 'DD/MM/YYYY').format('YYYY-MM-DD HH:MM:SS');
        //Validação de datas e de cliente.



        const parametros = {
            data : {data, dataCriacao},
            cliente : { tamanho: atendimento.cliente.lenght}
        }
        const erros = this.valida(parametros);
        const existemErros = erros.lenght;

        if (existemErros) {
            return new Promise(function (resolve, reject) {
                reject(erros);
            });
        }
        else {
            const atendimentoDatado = { ...atendimento, data, dataCriacao };

            return repositorio.adiciona(atendimentoDatado)
                .then(function (resultados) {
                    const id = resultados.insertId
                    return { ...atendimento, id }
                });
        }


    }

    lista() {
        return repositorio.lista();

    }

    buscaPorId(id, res) {
        const sql = `SELECT * FROM atendimentos WHERE id=${id}`

        connection.query(sql, async (erro, resultados) => {
            const resultadoAtendimento = resultados[0];
            const cpf = resultadoAtendimento.cliente;
            if (erro) {
                res.status(400).json(erro);
            }
            else {
                const { data } = await axios.get(`http://localhost:8082/${cpf}`)

                resultadoAtendimento.cliente = data

                res.status(200).json(resultadoAtendimento);
            }
        })
    }

    altera(id, valores, res) {
        if (valores.data) {
            valores.data = moment(valores.data, 'DD/MM/YYYY').format('YYYY-MM-DD HH:MM:SS');
        }
        const sql = 'UPDATE atendimentos SET ? WHERE id=?'

        connection.query(sql, [valores, id], function (erro, resultados) {
            if (erro) {
                res.status(400).json(erro);
            }
            else {
                res.status(200).json({ ...valores, id });
            }
        });
    }

    deleta(id, res) {
        const sql = 'DELETE FROM atendimentos WHERE id = ?'

        connection.query(sql, id, function (erro, resultados) {
            if (erro) {
                res.status(400).json(erro);
            }
            else {
                res.status(200).json({ id });
            }
        })
    }

}


module.exports = new Atendimento;