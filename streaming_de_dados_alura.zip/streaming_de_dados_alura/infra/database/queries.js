const connection = require ('./connection');

const executaQuery = function(query, parametros = ''){
    return new Promise (function(resolve, reject) {
        connection.query(query, parametros, function(erros, resultados){
            if(erros){
                reject(erros);
            } 
            else {
                resolve(resultados);
            }
        });

    });
};

module.exports = executaQuery;