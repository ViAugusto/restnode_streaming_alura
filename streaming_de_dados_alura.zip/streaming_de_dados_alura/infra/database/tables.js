class Tabelas {
    init(connection) {
        this.connection = connection;

        this.criarAtendimento();

        this.criarPets();
    }

    criarAtendimento() {
        const sql = 'CREATE TABLE IF  NOT EXISTS Atendimentos (id INT NOT NULL AUTO_INCREMENT, cliente VARCHAR(11) NOT NULL, pet VARCHAR(20), servico VARCHAR(20) NOT NULL, data datetime NOT NULL, dataCriacao datetime NOT NULL, status VARCHAR(20) NOT NULL, observacoes TEXT, PRIMARY KEY(id))'

        this.connection.query(sql, erro => {
            if (erro) {
                console.log(erro);
            }
            else {
                console.log('Tabela criada com sucesso.')
            }
        });
    }

    criarPets() {
        const query = 'CREATE TABLE IF NOT EXISTS pets (id INT NOT NULL AUTO_INCREMENT, nome VARCHAR(50), imagem VARCHAR(200), PRIMARY KEY (ID))'

        this.connection.query(query, function(erro) {
            if(erro){
                console.log(erro);
            }
            else {
                console.log('Tabela pet criada com sucesso')
            }
        });
    }

}

module.exports = new Tabelas;