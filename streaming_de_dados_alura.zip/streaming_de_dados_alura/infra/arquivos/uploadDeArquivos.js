const fs = require('fs');
const path = require('path');

module.exports = function (caminho, nomeDaImagem, callbackImagemCriada) {
    const tiposValidos = ['jpg', 'png', 'jpeg'];
    const tipo = path.extname(caminho);
    const validarTipo = tiposValidos.indexOf(tipo.substring(1)) != -1;
    
    if (validarTipo) {
        

        
        const novoCaminho = `./assets/img/${nomeDaImagem}${tipo}`;
        fs.createReadStream(caminho)
            .pipe(fs.createWriteStream(novoCaminho))
            .on('finish', function () {
                callbackImagemCriada(false, novoCaminho)
            });

    }
    else {
        const erro = 'Tipo é inválido';
        console.log('Tá errado meu chefe')
        callbackImagemCriada(erro);
    }
}
