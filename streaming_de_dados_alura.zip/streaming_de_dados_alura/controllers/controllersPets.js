const Pet = require('../models/pets');

module.exports = function(app) {
    app.post('/pet', function(req, res){
        const pet = req.body;

        Pet.adiciona(pet, res);
    });
}